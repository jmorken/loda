import os

# import time
import psutil  # type `pip install psutil` at command line to install
from subprocess import Popen
from subprocess import TimeoutExpired


# the dir containing loda.exe
app_dir = os.getcwd()

cmd = [os.path.join(app_dir, "loda.exe"), "mine", "-P", "10"]


def get_loda_pids():
    """
    returns a list of process ids integers where the name of the
    process is `loda.exe`
    """
    pids = []
    for proc in psutil.process_iter(["pid", "name"]):
        if proc.info["name"] == "loda.exe":
            print(f"found loda.exe process {proc.info}")
            pids.append(proc.info["pid"])
    return pids


def on_terminate(proc):
    """prints a message to the console when a process is terminated"""
    print(
        "process {} terminated with exit code {}".format(proc, proc.returncode)
    )


def kill_procs(pids):
    """kill all processes with process ids in the specified list of process ids
    Args:
        pids (list): list of integer process ids
    """
    procs = [psutil.Process(pid) for pid in pids]
    for p in procs:
        if p.name() == "loda.exe":
            p.terminate()
    gone, alive = psutil.wait_procs(procs, timeout=3, callback=on_terminate)
    for p in alive:
        if p.name() == "loda.exe":
            p.kill()


sleepTimer = 43200  # this is seconds (43200 is 12hours)
# delayTimer=10 #optional I guess

# kill any residual loda processes on startup
kill_procs(get_loda_pids())

while True:

    print("restarting Loda miner every " + str(sleepTimer) + " seconds")
    with Popen(cmd) as p:
        try:
            p.wait(timeout=sleepTimer)
            # after waiting for timeout seconds, kill all loda procs
        except TimeoutExpired:
            kill_procs(get_loda_pids())
        except:  # Including KeyboardInterrupt, wait handled that.
            p.kill()
            # We don't call p.wait() again as p.__exit__ does that for us.
            raise